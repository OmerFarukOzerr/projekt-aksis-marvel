package com.example.project_aksis.util

object Constants {
    const val BASE_URL = "https://gateway.marvel.com/"

    const val PUBLIC_KEY = "77d174521b4379ef387784a8ef738818"

    const val PRIVATE_KEY = "90861235491e0fa6e581286d1e28c8cf9a41de73"

    const val ORDER_DEF = "name"

    const val ORDER_DESC = "-name"

    const val NO_NETWORK_CONNECTION = "no_network_connection"

    const val NULL_DATA = "null_data"

    const val OTHER_ERROR = "other_error"

    const val EMPTY_DB = "Try to add something Favorite"

}

